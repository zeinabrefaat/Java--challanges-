
import java.util.Scanner;

public class ArmstrongNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the upper limit (N):");
        int N = scanner.nextInt();
        
        System.out.println("Armstrong Numbers:");
        for (int i = 1; i <= N; i++) {
            if (isArmstrong(i)) {
                System.out.print(i + " ");
            }
        }
    }
    
    public static boolean isArmstrong(int num) {
        int sum = 0, original = num;
        int digits = String.valueOf(num).length();
        
        while (num > 0) {
            int digit = num % 10;
            sum += Math.pow(digit, digits);
            num /= 10;
        }
        
        return sum == original;
    }
}
